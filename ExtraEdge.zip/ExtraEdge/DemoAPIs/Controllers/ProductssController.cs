﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using DemoAPIs.Models;
namespace DemoAPIs.Controllers
{
    [EnableCors("*", "*","*")]
    public class ProductssController : ApiController
    {
        ProductDBEntities db = new ProductDBEntities();

        // GET api/Emps
        public IEnumerable<Product> Get()
        {
            return db.Products.ToList();
        }

        // GET api/Emps/5
        public Product Get(int id)
        {
            return db.Products.Find(id);
        }

        // POST api/Emps
        public void Post([FromBody] Product emp)
        {
            db.Products.Add(emp);
            db.SaveChanges();
        }

        // PUT api/Emps/5
        public void Put(int id, [FromBody] Product product)
        {
            Product productToBeModified = db.Products.Find(id);
            productToBeModified.Name = product.Name;
            productToBeModified.Category = product.Category;
            productToBeModified.Price = product.Price;
            db.SaveChanges();
        }

        // DELETE api/Emps/5
        public void Delete(int id)
        {
            Product productToBeDeleted = db.Products.Find(id);
            db.Products.Remove(productToBeDeleted);
            db.SaveChanges();
        }
    }

    
}


